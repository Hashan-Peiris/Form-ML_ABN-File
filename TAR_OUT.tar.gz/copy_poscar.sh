#!/bin/bash

mypath="$(pwd)"
dir_name=ALL_POSCARS	## Change Directory name here!
mkdir "$dir_name"

for i in `seq 1  1 100`; do 
echo $i; 
mkdir $mypath/"$dir_name"/"$i"
cd $mypath/"$dir_name"/"$i"

cp $mypath/tmp_poscars/POSCAR_"$i"	$mypath/"$dir_name"/"$i"/POSCAR 
cp $mypath/INCAR			$mypath/"$dir_name"/"$i"/INCAR 
cp $mypath/POTCAR			$mypath/"$dir_name"/"$i"/POTCAR 
cp $mypath/KPOINTS			$mypath/"$dir_name"/"$i"/KPOINTS 
#cp $mypath/job_control.txt 		$mypath/"$dir_name"/"$i"/job_control.txt 

#rm $mypath/"$dir_name"/"$i"/DDEC*


#M=$(grep "piece" travis.log);
#echo "$i $M" >> $mypath/Collection/"$i"/MOLECULE_LIST.txt
#echo "" 	 >> $mypath/Collection/"$i"/MOLECULE_LIST.txt

#rm -v $mypath/"$dir_name"/"$i"/{AECCAR0,AECCAR1,AECCAR2,OSZICAR,OUTCAR}

cd 	../

done


