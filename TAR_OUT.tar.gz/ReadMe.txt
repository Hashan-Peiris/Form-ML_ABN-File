770 upwards are the 108 atom cells. Below 769 are 286 atom cells.
This will mean mean either 444 or 111 KPOINT grids needs to be used. 

Also this will dictate whether to use vasp_std or vasp_std.


The scripts will need to be run in the order of:

./copy_poscar.sh    # will copy all the poscars from 1 to 1321 in the directory ./ALL_POSCARS/$dir_num"
./rvSBATCH.sh       # Need to edit for vasp_gam and vasp_std and modules and slurm settings)
./submit.sh         # I have all the numbers that need to be run in each 'for' loop. (Refer to OSZI_Health.txt file) 
						Just need to comment out when running a line. 
