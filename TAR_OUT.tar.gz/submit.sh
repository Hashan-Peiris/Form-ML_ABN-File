#!/bin/bash
#SBATCH  -J RecSUBMIT
#SBATCH  -p quick			#SmeuResearch,defq,Standard
##SBATCH  -w compute159 		#or --nodelist=node0xx Assigns the said node 	##40 for 143/144 162/162 166/167 ##32 for 164/165 and SmeuC
##SBATCH --constraint=E5v2			#E5v4
##SBATCH --exclude=compute[000-070]
##SBATCH --exclusive		
##SBATCH -t 12:00:00
##SBATCH -N 1
#SBATCH  -n 1
##SBATCH --mem-per-cpu=4096
##SBATCH  --contiguous

#SBATCH  --mail-user=mpeiris1@binghamton.edu
#SBATCH  --mail-type=begin  # email me when the job starts
#SBATCH  --mail-type=end     # email me when the job finishes

#############################################################################################
#This submits jobs to Spiedie

#find <target-dir> -type d -maxdepth 1 -exec cp <the file> {} \;
#find /data/home/mpeiris1/LAMMPS/SiO2/Temperature/ReaxFF/ffield.reax.SiO2     -type f -maxdepth 1 -exec cp <the file> {} \;

mypath="$(pwd)"
dir_name=ALL_POSCARS	## Change Directory name here!
mkdir "$dir_name"

for i in  28 29 34 39 40 47 48 49 50 51 63 223 423 424 425 426 427 428 429 430 432 485 539 541 542 545 546 547 548 549 550 ; do
#for i in  554 555 556 557 558 568 569 570 577 578 581 588 589 591 594 595 596 744 745 746 747 769 791 792 807 809 839 840 841 1089 1090 1091 1092 1098 1124 1125 1126 1127 ; do

#for i in `seq  67 1 100`; do
#for i in `seq 435 1 479`; do
#for i in `seq 661 1 700`; do
#for i in `seq 705 1 715`; do
#for i in `seq 719 1 728`; do
#for i in `seq 730 1 737`; do
#for i in `seq 749 1 766`; do
#for i in `seq 826 1 833`; do
#for i in `seq 849 1 999`; do
#for i in `seq 1251 1 1321`; do

echo "$i"
#mkdir $mypath/"$dir_name"/"$i"
cd $mypath/"$dir_name"/"$i"

#rm -v $mypath/"$dir_name"/"$i"/{AECCAR*,*.vasp,OUTCAR,OSZICAR,*.xyz,slurm*}


## LAUNCHES THE FOLLOWING FROM $mypath/"$dir_name"/"$i"
sbatch 	runVASP.sh

cd 	../       			#### MOVE BACK TO ORIGIN
done


#############################################################################################

