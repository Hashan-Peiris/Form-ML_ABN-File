#!/bin/bash

mypath="$(pwd)"
dir_name=ALL_POSCARS	## Change Directory name here!
mkdir "Collection"
mkdir "Spin_Collection"
cp strip_bottom.py $mypath/Collection/strip_bottom.py
cp strip_bottom_spin.py $mypath/Spin_Collection/strip_bottom_spin.py

for i in `seq 1 1 1321`; do
#for i in `seq 500 1 600`; do

echo $i; 
cd $mypath/"$dir_name"/"$i"

#cp $mypath/"$dir_name"/"$i"/DDEC6_even_tempered_net_atomic_charges.xyz	$mypath/Collection/DDEC6_even_tempered_net_atomic_charges_"$i".xyz
#cp $mypath/"$dir_name"/"$i"/DDEC6_even_tempered_atomic_spin_moments.xyz $mypath/Spin_Collection/DDEC6_even_tempered_atomic_spin_moments_"$i".xyz

cp $mypath/"$dir_name"/"$i"/OUTCAR $mypath/Collection/OUTCAR_"$i"

#cp $mypath/"$dir_name"/"$i"/CONTCAR $mypath/"$dir_name"/"$i"/POSCAR

H=$(tail -2  OSZICAR);
echo -e "$i $j\n		$H\n"  | fmt -w 150 >> $mypath/OSZI_Health.xls

rm TIME_TAKEN.xls
T=$(grep "Total CPU time used (sec)" OUTCAR | tail -1);
echo "$i $T" >> $mypath/TIME_TAKEN.xls

#M=$(grep "piece" travis.log);
#echo "$i $M" >> $mypath/Collection/"$i"/MOLECULE_LIST.txt
#echo "" 	 >> $mypath/Collection/"$i"/MOLECULE_LIST.txt

#if [ -f CONTCAR ]		#if CONTCAR exists..
#then
#  if [ -s CONTCAR  ] 	#if CONTCAR is non-zero..
#  then
#	#mv	CONTCAR			$mypath/"$dir_name"/"$i"//POSCAR		## Move CONTCAR to POSCAR
#	if [ $? -eq 0 ]
#	then
#		echo "$i $j			CONTCAR exists; is non-zero ; move completed SUCCESSFULLY!!" 		>> $mypath/REPLACE_LOG.xls
#	else
#		echo "$i $j			CONTCAR exists; is non-zero ; movement fcukd!!" 			>> $mypath/REPLACE_LOG.xls
#	fi
#  else
#	echo "$i $j			CONTCAR exists; is ZERO ; movement not done!" 	>> $mypath/REPLACE_LOG.xls
#  fi
#else
#  echo "$i $j 		CONTCAR does not exist ; movement not done! --- **** " 		>> $mypath/REPLACE_LOG.xls
#fi

cd 	../

done


