#!/bin/bash

export OMP_NUM_THREADS=1
mypath="$(pwd)"

#Creates sbatch scripts in subdir(s)

mypath="$(pwd)"
dir_name=ALL_POSCARS	## Change Directory name here!
mkdir "$dir_name"

for i in `seq 1 1 1321 `; do 
echo $i; 
mkdir $mypath/"$dir_name"/"$i"
cd $mypath/"$dir_name"/"$i"

## CREATES THE FOLLOWING runVASP.sh in ~/"$dir_name"/"$i"

cat > runVASP.sh <<!
#!/bin/bash
#SBATCH -J SP_$i
#SBATCH -p  Standard    	#SmeuResearch,defq,Standard
##SBATCH -w compute159 		#or --nodelist=node0xx Assigns the said node 	##40 for 143/144 162/162 166/167 ##32 for 164/165 and SmeuC
#SBATCH --constraint="[E5v4|E5v3|HighMem|Scalable]"
##SBATCH  --exclusive		
##SBATCH -t 15:00:00
#SBATCH  -N 1-4     
#SBATCH  -n 16     
##SBATCH --mem-per-cpu=1512M
##SBATCH --contiguous

#SBATCH  --mail-user=mpeiris1@binghamton.edu
##SBATCH --mail-type=begin  # email me when the job starts
#SBATCH  --mail-type=end     # email me when the job finishes

#omp_threads=4
export OMP_NUM_THREADS=1
mypath="\$(pwd)"

module load VASP/OneAPI.6.4.2 
sleep 5
#module load VASP/5.4.4.new  

#mpirun vasp_gam 
#mpirun vasp_std

E=\$(grep "energy without entropy" OUTCAR | tail -1);
T=\$(grep "Total CPU time used (sec)" OUTCAR | tail -1);
L=\$(grep "free  energy   TOTEN  =" OUTCAR | tail -1);
Q=\$(grep -A9 "TOTAL ELASTIC MODULI (kBar)" OUTCAR)
M=\$(grep "Maximum memory used (kb)" OUTCAR | tail -1);
A=\$(grep "in kB" OUTCAR | tail -1);

echo " \$i  \$j \$E" >> KP_Ag.xls
echo " \$i  \$j \$Q" >> Elastic.xls
echo " \$i  \$j \$T" >> Time_Ag.xls
echo " \$i  \$j \$M" >> MxMemory_Ag.xls
echo " \$i  \$j \$L" >> OUT_KP_Val.xls
echo " \$i  \$j \$A" >> in_kB_val.xls

!

chmod +740 runVASP.sh

cd 	../       #### MOVE BACK TO ORIGIN
done

